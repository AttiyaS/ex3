#include <stdio.h>

#ifndef ROWS
#define ROWS 6
#endif

#ifndef COLS
#define COLS 7
#endif

#define CONNECT_N 4

/* Tokens */
#define EMPTY '.'
#define TOKEN_P1 'X'
#define TOKEN_P2 'O'

#define directions 4
#define HUMAN 1
#define COMPUTER 2

int isColumnFull(char[][COLS], int, int);

int isBoardFull(char[][COLS], int, int);

int isInBounds(int, int, int, int);

/* Return index of row where token will land, or -1 if column full */
int getFreeRow(char[][COLS], int, int);

/* Place token in column (0-based). Return row index or -1 if illegal */
int makeMove(char[][COLS], int, int, char);

int checkVictory(char[][COLS], int, int, int, int, char);

/* Human player: asks repeatedly until a valid non-full column is chosen (0-based) */
int humanChoose(char[][COLS], int, int);

/* Computer*/
int computerChoose(char board[][COLS], int rows, int cols, char playerToken, char opponentToken);
// void buildColumnOrder(int, int []);
void arrayOfOptions(int cols, int order[]);
int createsThree(char board[][COLS], int, int, int, int, char);
int isPcWinningMove(char[][COLS], int, int, char, char);

void runConnectFour(char[][COLS], int, int, int, int);

void initBoard(char[][COLS], int, int);

void printBoard(char[][COLS], int, int);

int getPlayerType(int);

int main()
{
    char board[ROWS][COLS];
    printf("Connect Four (%d rows x %d cols)\n\n", ROWS, COLS);
    int p1Type = getPlayerType(1);
    int p2Type = getPlayerType(2);
    initBoard(board, ROWS, COLS);
    printBoard(board, ROWS, COLS);
    runConnectFour(board, ROWS, COLS, p1Type, p2Type);
    return 0;
}

void printBoard(char board[][COLS], int rows, int cols)
{
    printf("\n");
    for (int r = 0; r < rows; r++)
    {
        printf("|");
        for (int c = 0; c < cols; c++)
        {
            putchar(board[r][c]);
            printf("|");
        }
        printf("\n");
    }
    for (int c = 1; c <= cols; c++)
    {
        printf(" %d", c % 10);
    }
    printf("\n\n");
}

int getPlayerType(int playerNumber)
{
    char ch;
    while (1)
    {
        printf("Choose type for player %d: h - human, c - computer: ", playerNumber);
        int n = scanf(" %c", &ch);
        if (n != 1)
        {
            printf("Input error. Try again.\n");
            while (getchar() != '\n')
                ; // clear input buffer
            continue;
        }
        if (ch == 'h' || ch == 'H')
            return HUMAN;
        if (ch == 'c' || ch == 'C')
            return COMPUTER;

        printf("Invalid selection. Enter h or c.\n");
        while (getchar() != '\n')
            ; // clear rest of input
    }
}

void runConnectFour(char board[][COLS], int rows, int cols, int p1Type, int p2Type)
{
    while (1)
    {
        int humanChoiceCol = 0, humanChoiceRow = 0;

        /* ==== Player 1 turn ==== */
        if (p1Type == HUMAN)
        {
            printf("Player 1 (%c) turn.\n", TOKEN_P1);
            humanChoiceCol = humanChoose(board, cols, rows);
            printf("Enter column (1-%d):\n ", cols);
            humanChoiceRow = makeMove(board, rows, humanChoiceCol, TOKEN_P1);
            if (humanChoiceRow == -1)
            {
                printf("Illegal move, try again.\n");
                continue;
            }

            printBoard(board, rows, cols);

            int vic = checkVictory(board, rows, cols, humanChoiceRow, humanChoiceCol, TOKEN_P1);
            if (vic)
            {
                printf("Player 1 (%c) wins!\n", TOKEN_P1);
                break;
            }
            else
            {
                int full = isBoardFull(board, rows, cols);
                if (full)
                {
                    printf("Board full and no winner. It's a tie!\n");
                    break;
                }
            }
        }
        else if (p1Type == COMPUTER)
        {
            printf("Player 1 (%c) turn.\n", TOKEN_P1);
            int pcCol = computerChoose(board, rows, cols, TOKEN_P1, TOKEN_P2);
            int pcRow = makeMove(board, rows, pcCol, TOKEN_P1);

            printBoard(board, rows, cols);

            int vic = checkVictory(board, rows, cols, pcRow, pcCol, TOKEN_P1);
            if (vic)
            {
                printf("Player 1 (%c) wins!\n", TOKEN_P1);
                break;
            }
            else
            {
                int full = isBoardFull(board, rows, cols);
                if (full)
                {
                    printf("Board full and no winner. It's a tie!\n");
                    break;
                }
            }
        }

        /* ==== Player 2 turn ==== */
        if (p2Type == HUMAN)
        {
            printf("Player 2 (%c) turn.\n", TOKEN_P2);
            humanChoiceCol = humanChoose(board, cols, rows);
            printf("Enter column (1-%d):\n ", cols);
            humanChoiceRow = makeMove(board, rows, humanChoiceCol, TOKEN_P2);
            printBoard(board, rows, cols);

            int vic = checkVictory(board, rows, cols, humanChoiceRow, humanChoiceCol, TOKEN_P2);
            if (vic)
            {
                printf("Player 2 (%c) wins!\n", TOKEN_P2);
                break;
            }
            else
            {
                int full = isBoardFull(board, rows, cols);
                if (full)
                {
                    printf("Board full and no winner. It's a tie!\n");
                    break;
                }
            }
        }
        else if (p2Type == COMPUTER)
        {
            printf("Player 2 (%c) turn.\n", TOKEN_P2);
            int pcCol = computerChoose(board, rows, cols, TOKEN_P2, TOKEN_P1);
            int pcRow = makeMove(board, rows, pcCol, TOKEN_P2);

            printBoard(board, rows, cols);

            int vic = checkVictory(board, rows, cols, pcRow, pcCol, TOKEN_P2);
            if (vic)
            {
                printf("Player 2 (%c) wins!\n", TOKEN_P2);
                break;
            }
            else
            {
                int full = isBoardFull(board, rows, cols);
                if (full)
                {
                    printf("Board full and no winner. It's a tie!\n");
                    break;
                }
            }
        }
    }
}
int isBoardFull(char board[][COLS], int rows, int cols)
{
    for (int c = 0; c < cols; c++)
    {
        if (!isColumnFull(board, rows, c))
            return 0;
    }
    return 1;
}
void initBoard(char board[][COLS], int rows, int cols)
{
    for (int r = 0; r < rows; r++)
    {
        for (int c = 0; c < cols; c++)
        {
            board[r][c] = EMPTY;
        }
    }
}
int checkVictory(char board[][COLS], int rows, int cols, int row, int col, char token)
{
    int directionVectors[4][2] = {
        {0, 1}, // Horizontal
        {1, 0}, // Vertical
        {1, 1}, // Diagonal down-right
        {1, -1} // Diagonal down-left
    };

    // checking all 4 directions
    for (int direction = 0; direction < 4; direction++)
    {
        int directionRows = directionVectors[direction][0]; // Vertical
        int directionCols = directionVectors[direction][1]; // Horizontal

        int count = 1; // Count the placed token

        int r = row + directionRows;
        int c = col + directionCols;

        // Check in the positive direction

        while (isInBounds(r, c, rows, cols) && board[r][c] == token)
        {
            count++;
            r = r + directionRows;
            c = c + directionCols;
        }

        r = row - directionRows;
        c = col - directionCols;

        // Check in the negative direction
        while (isInBounds(r, c, rows, cols) && board[r][c] == token)
        {
            count++;
            r = r - directionRows;
            c = c - directionCols;
        }

        if (count >= 4)
        {
            return 1; // Victory found
        }
    }

    return 0; // No victory
}

int isInBounds(int row, int col, int rows, int cols)
{
    return (row >= 0 && row < rows && col >= 0 && col < cols);
}

int makeMove(char board[][COLS], int rows, int col, char token)
{
    if (isColumnFull(board, rows, col))
    {
        return -1; // Column is full
    }
    int row = getFreeRow(board, rows, col);
    if (row != -1)
    {
        board[row][col] = token;
    }
    return row;
}
int isColumnFull(char board[][COLS], int rows, int col)
{

    for (int r = 0; r < rows; r++)
    {
        if (board[r][col] == EMPTY)
        {
            return 0; // Column is not full
        }
    }
    return 1; // Column is full
}
int getFreeRow(char board[][COLS], int rows, int col)
{
    for (int r = rows - 1; r >= 0; r--)
    {
        if (board[r][col] == EMPTY)
        {
            return r; // Return the first empty row from the bottom
        }
    }
    return -1; // Column is full
}
int humanChoose(char board[][COLS], int cols, int rows)
{

    while (1)
    {
        int col;
        int validInput = scanf("%d", &col);
        if (validInput != 1)
        {
            printf("Enter column (1-%d): Invalid input. Enter a number.\n", cols);

            while (getchar() != '\n')
                ; // if not a number, clear input buffer

            continue;
        }
        col--; // Convert to 0-based index
        if (col < 0 || col >= cols)
        {
            printf("Enter column (1-%d): Invalid column. Choose between 1 and %d.\n", COLS, COLS);
            continue;
        }
        if (isColumnFull(board, rows, col))
        {
            printf("Enter column (1-%d): Column %d is full. Choose another column.\n", COLS, col + 1);
            continue;
        }
        return col;
    }
}
void arrayOfOptions(int cols, int order[])
{
    int idx = 0;

    // odd number of columns
    if (cols % 2 == 1)
    {
        int center = cols / 2;
        order[idx++] = center;

        for (int d = 1; idx < cols; d++)
        {
            if (center - d >= 0)
                order[idx++] = center - d;

            if (center + d < cols)
                order[idx++] = center + d;
        }
    }
    else // even number of columns
    {
        int leftCenter = cols / 2 - 1;
        int rightCenter = cols / 2;

        for (int d = 0; idx < cols; d++)
        {
            if (leftCenter - d >= 0)
                order[idx++] = leftCenter - d;

            if (rightCenter + d < cols)
                order[idx++] = rightCenter + d;
        }
    }
}
int createsThree(char board[][COLS], int rows, int cols, int row, int col, char token)
{
    int directionVectors[4][2] = {
        {0, 1},
        {1, 0},
        {1, 1},
        {1, -1}};

    for (int d = 0; d < 4; d++)
    {
        int dr = directionVectors[d][0];
        int dc = directionVectors[d][1];

        int count = 1; //

        int r = row + dr;
        int c = col + dc;

        // positive direction
        while (isInBounds(r, c, rows, cols) && board[r][c] == token)
        {
            count++;
            r += dr;
            c += dc;
        }

        // כיוון שלילי
        r = row - dr;
        c = col - dc;
        while (isInBounds(r, c, rows, cols) && board[r][c] == token)
        {
            count++;
            r -= dr;
            c -= dc;
        }

        if (count >= 3 && count < 4) // שלישייה (לא חובה להוסיף '<4', אבל זה יותר "נקי")
            return 1;
    }

    return 0;
}
int computerChoose(char board[][COLS], int rows, int cols,
                   char playerToken, char opponentToken)
{
    int order[COLS];
    arrayOfOptions(cols, order);

    // 1. Winning move
    for (int i = 0; i < cols; i++)
    {
        int col = order[i];
        if (!isColumnFull(board, rows, col))
        {
            int row = getFreeRow(board, rows, col);
            board[row][col] = playerToken;

            if (checkVictory(board, rows, cols, row, col, playerToken))
            {
                board[row][col] = EMPTY;
                printf("Computer chose column %d\n", col + 1);
                return col;
            }

            board[row][col] = EMPTY;
        }
    }

    // 2. Block opponent's winning move
    for (int i = 0; i < cols; i++)
    {
        int col = order[i];
        if (!isColumnFull(board, rows, col))
        {
            int row = getFreeRow(board, rows, col);
            board[row][col] = opponentToken;

            if (checkVictory(board, rows, cols, row, col, opponentToken))
            {
                board[row][col] = EMPTY;
                printf("Computer chose column %d\n", col + 1);
                return col;
            }

            board[row][col] = EMPTY;
        }
    }

    // 3. Creating a sequence of three (for the computer)
    for (int i = 0; i < cols; i++)
    {
        int col = order[i];
        if (isColumnFull(board, rows, col))
            continue;

        int row = getFreeRow(board, rows, col);
        board[row][col] = playerToken;

        if (createsThree(board, rows, cols, row, col, playerToken))
        {
            board[row][col] = EMPTY;
            printf("Computer chose column %d\n", col + 1);
            return col;
        }

        board[row][col] = EMPTY;
    }

    // 4. Blocking opponent’s sequence of three
    for (int i = 0; i < cols; i++)
    {
        int col = order[i];
        if (isColumnFull(board, rows, col))
            continue;

        int row = getFreeRow(board, rows, col);
        board[row][col] = opponentToken;

        if (createsThree(board, rows, cols, row, col, opponentToken))
        {
            board[row][col] = EMPTY;
            printf("Computer chose column %d\n", col + 1);
            return col;
        }

        board[row][col] = EMPTY;
    }

    // 5. Default: first legal column according to order[]
    for (int i = 0; i < cols; i++)
    {
        int col = order[i];
        if (!isColumnFull(board, rows, col))
        {
            printf("Computer chose column %d\n", col + 1);
            return col;
        }
    }

    return 0;
}